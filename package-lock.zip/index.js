const express = require('express');
const path = require('path');
const admin = require('firebase-admin');
const cors = require('cors');

// Initialize Firebase Admin
const serviceAccount = require('./jenn-dbd35-firebase-adminsdk-fbsvc-9decc65db5.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();
const app = express();

// Middleware
app.use(cors({ origin: 'http://localhost:3000' }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', message: 'Server is running' });
});

// Create a new user (POST /users)
app.post('/users', async (req, res) => {
  try {
    const { name, email } = req.body;

    console.log('Received data:', { name, email });

    // Validate inputs
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Name is required and cannot be empty' });
    }
    if (!email || !email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/i)) {
      return res.status(400).json({ error: 'Valid email is required' });
    }

    // Save to Firestore
    const docRef = await db.collection('users').add({
      name: name.trim(),
      email: email.toLowerCase(),
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });

    res.status(201).json({
      id: docRef.id,
      message: 'User created successfully',
      name: name.trim(),
      email: email.toLowerCase()
    });
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ error: 'Failed to save data: ' + err.message });
  }
});

// Read all users (GET /users)
app.get('/users', async (req, res) => {
  try {
    const snapshot = await db.collection('users').orderBy('timestamp', 'desc').get();
    const users = snapshot.docs.map(doc => ({
      id: doc.id,
      name: doc.data().name,
      email: doc.data().email,
      timestamp: doc.data().timestamp
    }));
    res.status(200).json(users);
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({ error: 'Failed to fetch users: ' + err.message });
  }
});

// Update a user (PUT /users/:id)
app.put('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email } = req.body;

    console.log('Received update data:', { id, name, email });

    // Validate inputs
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Name is required and cannot be empty' });
    }
    if (!email || !email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/i)) {
      return res.status(400).json({ error: 'Valid email is required' });
    }

    // Update in Firestore
    await db.collection('users').doc(id).update({
      name: name.trim(),
      email: email.toLowerCase(),
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });

    res.status(200).json({
      id,
      message: 'User updated successfully',
      name: name.trim(),
      email: email.toLowerCase()
    });
  } catch (err) {
    console.error('Error updating user:', err);
    res.status(500).json({ error: 'Failed to update user: ' + err.message });
  }
});

// Delete a user (DELETE /users/:id)
app.delete('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;

    console.log('Received delete request for id:', id);

    // Delete from Firestore
    await db.collection('users').doc(id).delete();

    res.status(200).json({ message: 'User deleted successfully', id });
  } catch (err) {
    console.error('Error deleting user:', err);
    res.status(500).json({ error: 'Failed to delete user: ' + err.message });
  }
});

// Serve index.html for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});